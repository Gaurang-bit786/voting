from django.contrib import admin
from .models import Vote, Category,Student, Branche
from django.contrib.auth.models import Group

class CatAdmin(admin.ModelAdmin):
    list_display = ['category_name','active']
    list_filter = ['category_name','active']
    search_fields = ['category_name','active']



admin.site.register(Student)
admin.site.register(Branche)
admin.site.register(Vote)
admin.site.register(Category,CatAdmin)
admin.site.unregister(Group)