from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import *


def dashboard(request):
    if request.user.is_authenticated:
        return render(request,'main.html')
    else:
        return redirect('login')



def index(request):
    if request.user.is_authenticated:
        return render(request,'home.html')
    else:
        return redirect('login')


def voters(request):
    if request.user.is_authenticated:
        cat = Category.objects.get(active=True)
        student = Student.objects.filter(category=cat)
        user = User.objects.get(id=request.user.id)
        try:
            votes = Vote.objects.get(user=user,category=cat)
            return render(request,'votes.html',{'cat':cat,'student':student,'vote':votes})
        except:
            return render(request,'votes.html',{'cat':cat,'student':student})
    else:
        return redirect('login')


def save_vote(request):
    if request.method == 'POST':
        print(request.POST.get('value'))
        print(request.POST.get('cat'))
        cat = Category.objects.get(category_name=request.POST.get('cat'))
        stu = Student.objects.get(roll_no=request.POST.get('value'),category=cat)
        user = User.objects.get(id=request.user.id)
        print(user)
        vote = Vote(user=user,name=stu.name,roll_no=stu.roll_no,category=cat,branch=stu.branch)
        vote.save()
        return redirect('index')
    else:
        return redirect('login')


def analysis(request):
    if request.user.is_authenticated:
        vote = Vote.objects.filter(roll_no=2000050060010,category=1).count()
        print(vote)
        return render(request,'analysis.html')
    else:
        return redirect('login')